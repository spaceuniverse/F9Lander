# just a placeholder
import os

os.system("python LoopCORE.py")

print "done"