+ install:

pip install flask-restful
pip install Flask


http://flask.pocoo.org/docs/0.10/quickstart/#
http://flask.pocoo.org/docs/0.10/installation/#installation

https://flask-restful.readthedocs.org/en/0.3.5/quickstart.html
https://flask-restful.readthedocs.org/en/0.3.5/installation.html#installation

help:

http://blog.miguelgrinberg.com/post/designing-a-restful-api-using-flask-restful
http://blog.miguelgrinberg.com/post/designing-a-restful-api-with-python-and-flask

