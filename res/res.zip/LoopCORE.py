# just a placeholder
for i in xrange(10):
    print "Hello"